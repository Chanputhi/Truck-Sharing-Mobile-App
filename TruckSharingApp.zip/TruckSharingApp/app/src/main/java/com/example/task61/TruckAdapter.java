package com.example.task61;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task61.model.Truck;

import java.util.List;

public class TruckAdapter extends RecyclerView.Adapter<TruckAdapter.ViewHolder> {

    private List<Truck> truckList;
    private Context context;

    public TruckAdapter(List<Truck> truckList, Context context) {
        this.truckList = truckList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.truck_row, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.truckImageView.setImageResource(truckList.get(position).getTruckImage());
        holder.truckTitleTextView.setText(truckList.get(position).getTruckTitle());
        holder.vehicleTextView.setText(truckList.get(position).getVehicle());
        holder.goodsTextView.setText(truckList.get(position).getGoods());
        holder.dateTextView.setText(truckList.get(position).getDate());

        //Share Button of Truck to other
        holder.shareImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);

                sharingIntent.setType("text/plain");

                String shareBody = "Share Body Here";
                String shareSubject = "Share Subject Here";

                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);

                view.getContext().startActivity(Intent.createChooser(sharingIntent, "Share using"));
            }
        });

    }

    @Override
    public int getItemCount() {
        return truckList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView truckImageView;
        TextView truckTitleTextView;
        TextView vehicleTextView;
        TextView goodsTextView;
        TextView dateTextView;
        ImageButton shareImageButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            truckImageView = itemView.findViewById(R.id.truckImageView);
            truckTitleTextView = itemView.findViewById(R.id.truckTitleTextView);
            vehicleTextView = itemView.findViewById(R.id.vehicleTextView);
            goodsTextView = itemView.findViewById(R.id.goodsTextView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            shareImageButton = itemView.findViewById(R.id.shareImageButton);
        }
    }
}
