package com.example.task61.model;

import android.graphics.Bitmap;

public class Truck {

    private int truck_id;
    private int truckImage;
    private String truckTitle;
    private String vehicle;
    private String goods;
    private String date;

    public Truck(int truck_id, int truckImage, String truckTitle, String vehicle, String goods, String date) {
        this.truck_id = truck_id;
        this.truckImage = truckImage;
        this.truckTitle = truckTitle;
        this.vehicle = vehicle;
        this.goods = goods;
        this.date = date;
    }

    public Truck() {}

    public int getTruck_Id() {
        return truck_id;
    }

    public void setTruck_Id(int truck_id) {
        this.truck_id = truck_id;
    }

    public int getTruckImage() {
        return truckImage;
    }

    public void setTruckImage(int truckImage) {
        this.truckImage = truckImage;
    }

    public String getTruckTitle() {
        return truckTitle;
    }

    public void setTruckTitle(String truckTitle) {
        this.truckTitle = truckTitle;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }

    public String getGoods() {
        return goods;
    }

    public void setGoods(String goods) {
        this.goods = goods;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
