package com.example.task61;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.task61.model.Order;
import com.example.task61.model.Truck;
import com.example.task61.util.Util;

import java.util.List;

public class OrderRecyclerView extends RecyclerView.Adapter<OrderRecyclerView.ViewHolder> {

    private final List<Order> orderList;
    private final Context context;

    public OrderRecyclerView(List<Order> orderList, Context context) {
        this.orderList = orderList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.order_row, parent, false);

        return new OrderRecyclerView.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Bitmap imageBitmap = NewDeliveryOrderOneActivity.getImage(orderList.get(position).getOrderImage());
//        holder.orderImageView.setImageResource(orderList.get(position).getOrderImage());
        holder.orderImageView.setImageBitmap(imageBitmap);
        holder.receiverNameTextView.setText(orderList.get(position).getOrderReceiverName());
        holder.orderDateTextView.setText(orderList.get(position).getOrderDate());
        holder.orderTimeTextView.setText(orderList.get(position).getOrderTime());
        holder.orderLocationTextView.setText(orderList.get(position).getOrderLocation());

        //Share Button of Order Item to other
        holder.shareImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);

                sharingIntent.setType("text/plain");

                String shareBody = "Share Body Here";
                String shareSubject = "Share Subject Here";

                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);

                view.getContext().startActivity(Intent.createChooser(sharingIntent, "Share using"));
            }
        });

        // When click on each item on recycler view
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, orderList.get(position).getOrderReceiverName(), Toast.LENGTH_SHORT).show();

                Intent orderDetailIntent = new Intent(view.getContext(), OrderDetailActivity.class);
                orderDetailIntent.putExtra(Util.ORDER_ID, position);

                view.getContext().startActivity(orderDetailIntent);
//                context.startActivity(orderDetailIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView orderImageView;
        TextView receiverNameTextView;
        TextView orderDateTextView;
        TextView orderTimeTextView;
        TextView orderLocationTextView;
        ImageButton shareImageButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            orderImageView = itemView.findViewById(R.id.orderImageView);
            receiverNameTextView = itemView.findViewById(R.id.receiverNameTextView);
            orderDateTextView = itemView.findViewById(R.id.orderDateTextView);
            orderTimeTextView = itemView.findViewById(R.id.orderTimeTextView);
            orderLocationTextView = itemView.findViewById(R.id.orderLocationTextView);
            shareImageButton = itemView.findViewById(R.id.shareImageButton);

        }
    }
}
