package com.example.task61.util;

import android.graphics.Bitmap;

public class Util {

//    User Database Helper
    public static final int DATABASE_VERSION = 1;
    public static final String USER_DATABASE_NAME = "user_db";
    public static final String USER_TABLE_NAME = "users";

    public static final String USER_ID = "user_id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

//    Truck Database Helper
    public static final String TRUCK_DATABASE_NAME = "truck_db";
    public static final String TRUCK_TABLE_NAME = "trucks";

    public static final String TRUCK_ID = "truck_id";
//    private static Byte truckImage;
    //public static final Bitmap TRUCK_IMAGE = truckImage;
    public static final String TRUCK_TITLE = "truckTitle";
    public static final String TRUCK_VEHICLE = "vehicle";
    public static final String TRUCK_GOODS = "goods";
    public static final String TRUCK_DATE = "date";


//    Order Database Helper
    public static final String ORDER_DATABASE_NAME = "order_db";
    public static final String ORDER_TABLE_NAME = "orders";

    public static final String ORDER_ID = "order_id";
    public static final String ORDER_IMAGE = "orderImage";
    public static final String ORDER_RECEIVER_NAME = "orderReceiverName";
    public static final String ORDER_DATE = "orderDate";
    public static final String ORDER_TIME = "orderTime";
    public static final String ORDER_LOCATION = "orderLocation";

    public static final String ORDER_GOODS = "orderGoods";
    public static final String ORDER_VEHICLE = "orderVehicles";
    public static final String ORDER_LENGTH = "orderLength";
    public static final String ORDER_HEIGHT = "orderHeight";
    public static final String ORDER_WEIGHT = "orderWeight";
    public static final String ORDER_QUANTITY = "orderQuantity";

}
