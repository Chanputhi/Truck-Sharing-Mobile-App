package com.example.task61.model;

import android.graphics.Bitmap;

public class Order {

    private int order_id;
    private String orderReceiverName;
    private String orderDate;
    private String orderTime;
    private String orderLocation;
    private String orderGoods;
    private String orderVehicles;
    private String orderLength;
    private String orderHeight;
    private String orderWeight;
    private String orderQuantity;

    private byte[] orderImage;

    public Order(byte[] orderImage, String orderReceiverName, String orderDate, String orderTime, String orderLocation,
                 String orderGoods, String orderVehicles, String orderLength, String orderHeight, String orderWeight, String orderQuantity) {
//        this.order_id = order_id;

        this.orderImage = orderImage;

        this.orderReceiverName = orderReceiverName;
        this.orderDate = orderDate;
        this.orderTime = orderTime;
        this.orderLocation = orderLocation;

        this.orderGoods = orderGoods;
        this.orderVehicles = orderVehicles;
        this.orderLength = orderLength;
        this.orderHeight = orderHeight;
        this.orderWeight = orderWeight;
        this.orderQuantity = orderQuantity;
    }

    public Order() {}

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public byte[] getOrderImage() {
        return orderImage;
    }

    public void setOrderImage(byte[] orderImage) {
        this.orderImage = orderImage;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getOrderLocation() {
        return orderLocation;
    }

    public void setOrderLocation(String orderLocation) {
        this.orderLocation = orderLocation;
    }

    public String getOrderReceiverName() {
        return orderReceiverName;
    }

    public void setOrderReceiverName(String orderReceiverName) {
        this.orderReceiverName = orderReceiverName;
    }

    public String getOrderGoods() {
        return orderGoods;
    }

    public void setOrderGoods(String orderGoods) {
        this.orderGoods = orderGoods;
    }

    public String getOrderVehicles() {
        return orderVehicles;
    }

    public void setOrderVehicles(String orderVehicles) {
        this.orderVehicles = orderVehicles;
    }

    public String getOrderLength() {
        return orderLength;
    }

    public void setOrderLength(String orderLength) {
        this.orderLength = orderLength;
    }

    public String getOrderHeight() {
        return orderHeight;
    }

    public void setOrderHeight(String orderHeight) {
        this.orderHeight = orderHeight;
    }

    public String getOrderWeight() {
        return orderWeight;
    }

    public void setOrderWeight(String orderWeight) {
        this.orderWeight = orderWeight;
    }

    public String getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(String orderQuantity) {
        this.orderQuantity = orderQuantity;
    }
}
