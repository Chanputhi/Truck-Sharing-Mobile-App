package com.example.task61;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.task61.data.OrderDatabaseHelper;
import com.example.task61.model.Order;
import com.example.task61.util.Util;

import java.util.List;

public class OrderDetailActivity extends AppCompatActivity {

    TextView senderNameTextView, pickUpTimeTextView, receiverNameTextView, dropOffTimeTimeTextView;
    TextView vehicleTextView, goodTextView, lengthTextView, heightTextView, weightTextView, quantityTextView;
    Button getEstimateButton;
    ImageView orderImageView;

    private int orderSelectedID;
    OrderDatabaseHelper db;
    Order order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);

        senderNameTextView = findViewById(R.id.senderNameTextView);
        pickUpTimeTextView = findViewById(R.id.pickUpTimeTextView);
        receiverNameTextView = findViewById(R.id.receiverNameTextView);
        dropOffTimeTimeTextView = findViewById(R.id.dropOffTimeTimeTextView);
        vehicleTextView = findViewById(R.id.vehicleTextView);
        goodTextView = findViewById(R.id.goodTextView);
        lengthTextView = findViewById(R.id.lengthTextView);
        heightTextView = findViewById(R.id.heightTextView);
        weightTextView = findViewById(R.id.weightTextView);
        quantityTextView = findViewById(R.id.quantityTextView);
        getEstimateButton = findViewById(R.id.getEstimateButton);

        orderImageView = findViewById(R.id.orderImageView);

        db = new OrderDatabaseHelper(OrderDetailActivity.this);
        List<Order> orderList = db.fetchAllOrder();

        if (getIntent().hasExtra(Util.ORDER_ID))
        {

            orderSelectedID = getIntent().getIntExtra(Util.ORDER_ID, 0);
            order = orderList.get(orderSelectedID);

            String receiverName = order.getOrderReceiverName(); //1
            String pickUpTime = order.getOrderTime(); // 3
            String vehicle = order.getOrderVehicles(); // 6
            String goods = order.getOrderGoods(); // 5
            String length = order.getOrderLength(); // 7
            String height = order.getOrderHeight(); // 8
            String weight = order.getOrderWeight(); // 9
            String quantity = order.getOrderQuantity(); // 10

            Bitmap orderImage = NewDeliveryOrderOneActivity.getImage(order.getOrderImage());
            orderImageView.setImageBitmap(orderImage);

            senderNameTextView.setText("Chan Puthi");
            dropOffTimeTimeTextView.setText("Currently Unavailable");
            receiverNameTextView.setText(receiverName);
            pickUpTimeTextView.setText(pickUpTime);
            vehicleTextView.setText(vehicle);
            goodTextView.setText(goods);
            lengthTextView.setText(length);
            heightTextView.setText(height);
            weightTextView.setText(weight);
            quantityTextView.setText(quantity);
        }
        else
        {
            Log.e("Database123", "Intent Not found");
        }

        getEstimateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(OrderDetailActivity.this, "Estimate Begin", Toast.LENGTH_SHORT).show();

                Intent estimateIntent = new Intent(OrderDetailActivity.this, EstimateActivity.class);
                startActivity(estimateIntent);

            }
        });



    }
}