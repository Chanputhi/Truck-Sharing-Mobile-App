package com.example.task61;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.task61.data.OrderDatabaseHelper;
import com.example.task61.data.UserDatabaseHelper;
import com.example.task61.model.Order;
import com.example.task61.model.User;

public class NewDeliveryOrderTwoActivity extends AppCompatActivity {

    OrderDatabaseHelper db;
    Button createOrderButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_delivery_order_two);

        db = new OrderDatabaseHelper(NewDeliveryOrderTwoActivity.this);

        EditText lengthEditText = findViewById(R.id.lengthEdittext);
        EditText heightEditText = findViewById(R.id.heightEditText);
        EditText weightEditText = findViewById(R.id.weightEditText);
        EditText quantityEditText = findViewById(R.id.quantityEditText);

        Spinner goodsTypeSpinner = findViewById(R.id.goodsTypeSpinner);
        Spinner vehicleTypeSpinner = findViewById(R.id.vehicleTypeSpinner);
        createOrderButton =findViewById(R.id.createOrderButton);

        String[] goodsOption = {"Furniture", "Dry Goods", "Food", "Building Materials", "Other"};
        ArrayAdapter goodsAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, goodsOption);
        goodsTypeSpinner.setAdapter(goodsAdapter);

        String[] vehicleOption = {"Truck", "Van", "Refrigerated Truck", "Mini-truck", "Other"};
        ArrayAdapter vehicleAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, vehicleOption);
        vehicleTypeSpinner.setAdapter(vehicleAdapter);

        Intent getDeliveryIntent = getIntent();
        String receiverName = getDeliveryIntent.getStringExtra("orderReceiverName");
        String orderTime = getDeliveryIntent.getStringExtra("orderTime");
        String orderLocation = getDeliveryIntent.getStringExtra("orderLocation");
        String orderDate = getDeliveryIntent.getStringExtra("orderDate");

        byte[] orderImage = getDeliveryIntent.getByteArrayExtra("orderImage");



        createOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String goods = goodsTypeSpinner.getSelectedItem().toString();
                String vehicle = vehicleTypeSpinner.getSelectedItem().toString();

                String length = lengthEditText.getText().toString();
                String height = heightEditText.getText().toString();
                String weight = weightEditText.getText().toString();
                String quantity = quantityEditText.getText().toString();



                long result = 0;
                try{
//                    Order od = new Order(receiverName, orderTime, orderLocation, orderDate, goods, vehicle, length, height, weight, quantity);
                    Order order = new Order(orderImage, receiverName, orderDate, orderTime, orderLocation, goods, vehicle, length, height, weight, quantity);
                    result = db.insertOrder(order);

                    order.setOrder_id((int) result);

                }catch (Exception e){
                    Log.e("Error: ", orderImage + receiverName + orderDate + orderTime + orderLocation + goods +vehicle+length+height+weight+ quantity);
                }


                if (result > 0)
                {
                    Toast.makeText(getApplicationContext(), result+"", Toast.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), "Successfully Added", Toast.LENGTH_SHORT).show();
                    Intent orderIntent = new Intent(NewDeliveryOrderTwoActivity.this, MyOrderActivity.class);
                    startActivity(orderIntent);
                    finish();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "UnSuccessfully Added", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}