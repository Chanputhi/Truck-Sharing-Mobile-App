package com.example.task61;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;

import com.example.task61.data.OrderDatabaseHelper;
import com.example.task61.data.TruckDatabaseHelper;
import com.example.task61.model.Order;
import com.example.task61.model.Truck;

import java.util.ArrayList;
import java.util.List;

public class MyOrderActivity extends AppCompatActivity {

    ArrayList<Order> orderArrayList;
    OrderDatabaseHelper db;
    OrderRecyclerView orderAdapter;
    RecyclerView orderRecyclerView;

    Order order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_order);

        ImageButton menuButton = findViewById(R.id.menuButton);
        ImageButton addButton = findViewById(R.id.addButton);
        orderRecyclerView = findViewById(R.id.orderRecyclerView);

        orderArrayList = new ArrayList<>();
        db = new OrderDatabaseHelper(this);

        orderArrayList = (ArrayList<Order>) db.fetchAllOrder();

        orderAdapter= new OrderRecyclerView(orderArrayList, MyOrderActivity.this);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MyOrderActivity.this, RecyclerView.VERTICAL, false);
        orderRecyclerView.setLayoutManager(linearLayoutManager);
        orderRecyclerView.setAdapter(orderAdapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addDeliveryIntent = new Intent(MyOrderActivity.this, NewDeliveryOrderOneActivity.class);
                startActivity(addDeliveryIntent);
            }
        });

        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(MyOrderActivity.this, menuButton);

                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {

                        switch (menuItem.getItemId()) {
                            case R.id.home:
                                Intent homeIntent = new Intent(MyOrderActivity.this, HomeActivity.class);
                                startActivity(homeIntent);
                                return true;
                            case R.id.account:
                                Intent accountIntent = new Intent(MyOrderActivity.this, SignUpActivity.class);
                                startActivity(accountIntent);
                                return true;
                            case R.id.myOrders:
                                Intent orderIntent = new Intent(MyOrderActivity.this, MyOrderActivity.class);
                                startActivity(orderIntent);
                                return true;
                            case R.id.logout:
                                Intent logoutIntent = new Intent(MyOrderActivity.this, MainActivity.class);
                                startActivity(logoutIntent);
                                return true;
                            default:
                                return false;
                        }

                    }
                });

                popupMenu.show();
            }
        });
    }
}