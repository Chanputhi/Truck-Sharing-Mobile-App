package com.example.task61;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.task61.data.OrderDatabaseHelper;
import com.example.task61.data.UserDatabaseHelper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;

public class NewDeliveryOrderOneActivity extends AppCompatActivity {

    ImageButton nOrderImageButton;
    OrderDatabaseHelper db;

//    ImageButton newImageButton;
    byte[] byteImage;

    public static byte[] getBitmapAsByteArray(Bitmap bitmap) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 0, outputStream);
        return outputStream.toByteArray();
    }

    public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_delivery_order_one);

        EditText nOrderReceiverNameEditText = findViewById(R.id.nOrderReceiverNameEditText);
        EditText pickUpTimeEditText = findViewById(R.id.pickUpTimeEditText);
        EditText pickUpLocationEdittext = findViewById(R.id.pickUpLocationEditText);

        CalendarView calendarView = findViewById(R.id.calendarView);
        nOrderImageButton = findViewById(R.id.nOrderImageButton);
        Button nextOrderButton = findViewById(R.id.nextOrderButton);

//        newImageButton = findViewById(R.id.newImageButton);
//
        db = new OrderDatabaseHelper(this);



//
        nextOrderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String receiverName = nOrderReceiverNameEditText.getText().toString();
                String pickUpTime = pickUpTimeEditText.getText().toString();
                String pickUpLocation = pickUpLocationEdittext.getText().toString();

                Date orderDate = new Date(calendarView.getDate());
                String dateString = orderDate.toString();

                Intent addNextDeliveryIntent = new Intent(NewDeliveryOrderOneActivity.this, NewDeliveryOrderTwoActivity.class);

                addNextDeliveryIntent.putExtra("orderReceiverName", receiverName);
                addNextDeliveryIntent.putExtra("orderTime", pickUpTime);
                addNextDeliveryIntent.putExtra("orderLocation", pickUpLocation);
                addNextDeliveryIntent.putExtra("orderDate", dateString);

                addNextDeliveryIntent.putExtra("orderImage", byteImage);

                startActivity(addNextDeliveryIntent);

            }
        });

        nOrderImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent imageOrderIntent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                final int ACTIVITY_SELECT_IMAGE = 1234;
                startActivityForResult(imageOrderIntent, ACTIVITY_SELECT_IMAGE);
            }
        });

    }

    // Selected/got Image from photo gallery
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        switch(requestCode) {
            case 1234:
                if(resultCode == RESULT_OK){
                    Uri selectedImage = data.getData();
                    selectedImage.getPath();
                    String[] filePathColumn = {MediaStore.Images.Media.DATA};

                    Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                    cursor.moveToFirst();

                    nOrderImageButton.setImageURI(selectedImage);

                    int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                    String filePath = cursor.getString(columnIndex);
                    cursor.close();

                    Bitmap bitmapImage = null;
                    try {
                        bitmapImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                        Log.e("Database202", "Bitmap Try");
                    } catch (IOException e) {
                        e.printStackTrace();

                        Log.e("Database202", "Bitmap e: " + e.toString());
                    }
                    if(bitmapImage != null){
                        byteImage = getBitmapAsByteArray(bitmapImage);
                        Log.e("Database202", "Bitmap if: " + Arrays.toString(byteImage));

//                        newImageButton.setImageURI(selectedImage);
                    }

                }
        }

    };
}