package com.example.task61.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;

import androidx.annotation.Nullable;

import com.example.task61.model.Truck;
import com.example.task61.model.User;
import com.example.task61.util.Util;

import java.util.ArrayList;
import java.util.List;

public class TruckDatabaseHelper extends SQLiteOpenHelper {



    public TruckDatabaseHelper(@Nullable Context context) {
        super(context, Util.TRUCK_DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_TRUCK_TABLE = "CREATE TABLE " + Util.TRUCK_TABLE_NAME
                + "(" + Util.TRUCK_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
//                + Util.TRUCK_IMAGE + " BLOB, "
                + Util.TRUCK_TITLE + " TEXT, "
                + Util.TRUCK_VEHICLE + " TEXT, "
                + Util.TRUCK_GOODS + " TEXT, "
                + Util.TRUCK_DATE + " TEXT)";

        sqLiteDatabase.execSQL(CREATE_TRUCK_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String DROP_TRUCK_TABLE = "DROP TABLE IF EXISTS " + Util.TRUCK_TABLE_NAME;
        sqLiteDatabase.execSQL(DROP_TRUCK_TABLE, new String[]{Util.TRUCK_TABLE_NAME});

        onCreate(sqLiteDatabase);
    }

    public long insertTruck(Truck truck)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

//        contentValues.put(String.valueOf(Util.TRUCK_IMAGE), truck.getTruckImage());
        contentValues.put(Util.TRUCK_TITLE, truck.getTruckTitle());
        contentValues.put(Util.TRUCK_VEHICLE, truck.getVehicle());
        contentValues.put(Util.TRUCK_GOODS, truck.getGoods());
        contentValues.put(Util.TRUCK_DATE, truck.getDate());

        long newTruckRowId = db.insert(Util.TRUCK_TABLE_NAME, null, contentValues);
        db.close();

        return newTruckRowId;
    }

    public boolean fetchTruck(String truckTitle, String vehicle, String goods, String date)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.TRUCK_TABLE_NAME,
                new String[]{Util.TRUCK_ID},
//                Util.TRUCK_IMAGE + "=? and " +
                        Util.TRUCK_TITLE + "=? and " +
                        Util.TRUCK_VEHICLE + "=? and " +
                        Util.TRUCK_GOODS + "=? and " +
                        Util.TRUCK_DATE + "=?",
                new String[] {truckTitle, vehicle, goods, date},
                null, null, null);

        int truckRows = cursor.getCount();
        db.close();

        if(truckRows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public List<Truck> fetchAllTruck()
    {
        List<Truck> truckList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAllTruck = " SELECT * FROM " + Util.TRUCK_TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAllTruck, null);

        if(cursor.moveToFirst())
        {
            do {
                Truck truck = new Truck();
                truck.setTruck_Id(cursor.getInt(0));
                truck.setTruckTitle(cursor.getString(1));
                truck.setVehicle(cursor.getString(2));
                truck.setGoods(cursor.getString(3));
                truck.setDate(cursor.getString(4));

                truckList.add(truck);
            }while(cursor.moveToNext());
        }

        return truckList;
    }




}
