package com.example.task61.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.task61.model.User;
import com.example.task61.util.Util;

public class UserDatabaseHelper extends SQLiteOpenHelper {
    public UserDatabaseHelper(@Nullable Context context) {
        super(context, Util.USER_DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_USER_TABLE = "CREATE TABLE " + Util.USER_TABLE_NAME
                + "(" + Util.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Util.USERNAME + " TEXT, "
                + Util.PASSWORD + " TEXT)";

        sqLiteDatabase.execSQL(CREATE_USER_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String DROP_USER_TABLE = "DROP TABLE IF EXISTS";
        sqLiteDatabase.execSQL(DROP_USER_TABLE, new String[]{Util.USER_TABLE_NAME});

        onCreate(sqLiteDatabase);

    }

    public long insertUser(User user)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.USERNAME, user.getUsername());
        contentValues.put(Util.PASSWORD, user.getPassword());

        long newRowId = db.insert(Util.USER_TABLE_NAME, null, contentValues);
        db.close();

        return newRowId;
    }

    public boolean fetchUser(String username, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.USER_TABLE_NAME, new String[]{Util.USER_ID}, Util.USERNAME + "=? and " +
                Util.PASSWORD + "=?", new String[] {username, password}, null, null, null);

        int userRows = cursor.getCount();
        db.close();

        if(userRows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
