package com.example.task61.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.task61.NewDeliveryOrderTwoActivity;
import com.example.task61.model.Order;
import com.example.task61.util.Util;

import java.util.ArrayList;
import java.util.List;

public class OrderDatabaseHelper extends SQLiteOpenHelper {
    public OrderDatabaseHelper(@Nullable Context context) {
        super(context, Util.ORDER_DATABASE_NAME, null, Util.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String CREATE_ORDER_TABLE = "CREATE TABLE " + Util.ORDER_TABLE_NAME
                + "(" + Util.ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Util.ORDER_IMAGE + " BLOB, "
                + Util.ORDER_RECEIVER_NAME + " TEXT, "
                + Util.ORDER_DATE + " TEXT, "
                + Util.ORDER_TIME + " TEXT, "
                + Util.ORDER_LOCATION + " TEXT, "
                + Util.ORDER_GOODS + " TEXT, "
                + Util.ORDER_VEHICLE + " TEXT, "
                + Util.ORDER_LENGTH + " TEXT, "
                + Util.ORDER_HEIGHT + " TEXT, "
                + Util.ORDER_WEIGHT + " TEXT, "
                + Util.ORDER_QUANTITY + " TEXT)";

        sqLiteDatabase.execSQL(CREATE_ORDER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        String DROP_ORDER_TABLE = "DROP TABLE IF EXISTS " + Util.ORDER_TABLE_NAME;
        sqLiteDatabase.execSQL(DROP_ORDER_TABLE, new String[]{Util.ORDER_TABLE_NAME});

        onCreate(sqLiteDatabase);
    }

    public long insertOrder(Order order)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.ORDER_IMAGE, order.getOrderImage());
        contentValues.put(Util.ORDER_RECEIVER_NAME, order.getOrderReceiverName());
        contentValues.put(Util.ORDER_DATE, order.getOrderDate());
        contentValues.put(Util.ORDER_TIME, order.getOrderTime());
        contentValues.put(Util.ORDER_LOCATION, order.getOrderLocation());
        contentValues.put(Util.ORDER_GOODS, order.getOrderGoods());
        contentValues.put(Util.ORDER_VEHICLE, order.getOrderVehicles());
        contentValues.put(Util.ORDER_LENGTH, order.getOrderLength());
        contentValues.put(Util.ORDER_HEIGHT, order.getOrderHeight());
        contentValues.put(Util.ORDER_WEIGHT, order.getOrderWeight());
        contentValues.put(Util.ORDER_QUANTITY, order.getOrderQuantity());

        long newOrderRowId = db.insert(Util.ORDER_TABLE_NAME, null, contentValues);
        db.close();
        return newOrderRowId;
    }

    public boolean fetchOrder(String orderReceiverName, String orderDate, String orderTime, String orderLocation,
                              String orderGoods, String orderVehicles, String orderLength, String orderHeight, String orderWeight, String orderQuantity)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Util.ORDER_TABLE_NAME, new String[]{Util.ORDER_ID},

                Util.ORDER_RECEIVER_NAME + "=? and " +
                        Util.ORDER_DATE + "=? and " +
                        Util.ORDER_TIME + "=? and " +
                        Util.ORDER_LOCATION + "=? and " +
                        Util.ORDER_GOODS + "=? and " +
                        Util.ORDER_VEHICLE + "=? and " +
                        Util.ORDER_LENGTH + "=? and " +
                        Util.ORDER_HEIGHT + "=? and " +
                        Util.ORDER_WEIGHT + "=? and " +
                Util.ORDER_QUANTITY + "=?",
                new String[] {orderReceiverName, orderDate, orderTime, orderLocation,
                        orderGoods, orderVehicles, orderLength, orderHeight, orderWeight, orderQuantity},
                null, null, null);

//        cursor.getBlob(0);

        int orderRows = cursor.getCount();
        db.close();

        if(orderRows > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public List<Order> fetchAllOrder()
    {
        List<Order> orderList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectAllOrder = " SELECT * FROM " + Util.ORDER_TABLE_NAME;
        Cursor cursor = db.rawQuery(selectAllOrder, null);

        if(cursor.moveToFirst())
        {
            do {
                Order order = new Order();
                order.setOrder_id(cursor.getInt(0));
                order.setOrderImage(cursor.getBlob(1));
                order.setOrderReceiverName(cursor.getString(2));
                order.setOrderDate(cursor.getString(3));
                order.setOrderTime(cursor.getString(4));
                order.setOrderLocation(cursor.getString(5));
                order.setOrderGoods(cursor.getString(6));
                order.setOrderVehicles(cursor.getString(7));
                order.setOrderLength(cursor.getString(8));
                order.setOrderHeight(cursor.getString(9));
                order.setOrderWeight(cursor.getString(10));
                order.setOrderQuantity(cursor.getString(11));

                orderList.add(order);
            }while(cursor.moveToNext());
        }

        return orderList;
    }





}
