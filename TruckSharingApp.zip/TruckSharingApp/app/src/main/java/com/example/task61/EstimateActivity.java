package com.example.task61;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.task61.directionhelpers.FetchURL;
import com.example.task61.directionhelpers.TaskLoadedCallback;
import com.example.task61.util.PaymentsUtil;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wallet.AutoResolveHelper;
import com.google.android.gms.wallet.IsReadyToPayRequest;
import com.google.android.gms.wallet.PaymentData;
import com.google.android.gms.wallet.PaymentDataRequest;
import com.google.android.gms.wallet.PaymentsClient;
import com.google.android.gms.wallet.Wallet;
import com.google.android.gms.wallet.WalletConstants;
//import com.google.android.gms.wallet.databinding.ActivityCheckoutBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.util.Optional;

public class EstimateActivity extends AppCompatActivity implements OnMapReadyCallback, TaskLoadedCallback {

    // CHANPUTHI TITH
    // DEAKIN SIT305 MOBILE APP DEVELOPMENT
    // TASK 10.1D

    GoogleMap map;
    Button callDriverButton;
    View bookNowButton;
//    Button bookNowButton;

    MarkerOptions pickUpLocation, dropOffLocation;
    Polyline polyline;

    PaymentsClient paymentsClient;
    private static final int LOAD_PAYMENT_DATA_REQUEST_CODE = 168;
    private JSONObject paymentRequestJSON;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estimate);

        bookNowButton = findViewById(R.id.bookNowButton);;
        callDriverButton = findViewById(R.id.callDriverButton);

        // Route Map Part
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapFragment);
        mapFragment.getMapAsync(this);

        // -37.847204, 145.115400   : Deakin University (Pick Up)
        // -37.8638478,145.1123309  : Glen Waverly (Drop Off)
        pickUpLocation = new MarkerOptions().position(new LatLng(-37.847204, 145.115400)).title("Pick Up: Deakin University");
        dropOffLocation = new MarkerOptions().position(new LatLng(-37.8638478,145.1123309)).title("Drop Off: Glen Waverly");

        String url = getUrl(pickUpLocation.getPosition(), dropOffLocation.getPosition(), "driving");
        new FetchURL(EstimateActivity.this).execute(url, "driving");
        //


        // Call Driver Part
        callDriverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(EstimateActivity.this, "Call Driver", Toast.LENGTH_SHORT).show();
                // Driver Number
                String phoneNumber = "0123456789";
                // Call Intent
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber));
                startActivity(callIntent);
            }
        });
        //


        // Book Now Part with Google Pay Integration
        Wallet.WalletOptions  walletOptions = new Wallet.WalletOptions.Builder()
                .setEnvironment(WalletConstants.ENVIRONMENT_TEST)
                .build();

        paymentsClient = Wallet.getPaymentsClient(this, walletOptions);
        intitPayment();

        bookNowButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override

            public void onClick(View view) {
                loadPayment();
            }
        });
        //

    }

    //// Google Payment
    private void loadPayment() {
        final PaymentDataRequest paymentDataRequest = PaymentDataRequest.fromJson(paymentRequestJSON.toString());

        AutoResolveHelper.resolveTask(
                paymentsClient.loadPaymentData(paymentDataRequest),
                this,
                LOAD_PAYMENT_DATA_REQUEST_CODE
        );
    }

    private void intitPayment() {
        IsReadyToPayRequest isReadyToPayRequest = IsReadyToPayRequest.fromJson(baseConfigJSON().toString());

        Task<Boolean> task = paymentsClient.isReadyToPay(isReadyToPayRequest);
        task.addOnCompleteListener(this, new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {
                if(task.isSuccessful()){
                    showGooglePayButton(task.getResult());
                    Log.e("resultPay: ", "on completed");
                }else {
                    bookNowButton.setVisibility(View.GONE);
                }
            }
        });

        paymentRequestJSON = baseConfigJSON();
        try {
            paymentRequestJSON.put("transactionInfo", new JSONObject()
                    .put("totalPrice", "10")
                    .put("totalPriceStatus", "FINAL")
                    .put("currencyCode", "USD"));

            paymentRequestJSON.put("merchantInfo", new JSONObject()
                    .put("merchantId", "19216811")
                    .put("merchantName", "CHANPUTHITITH"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void showGooglePayButton(Boolean result) {
        if(result){
            bookNowButton.setVisibility(View.VISIBLE);
        }else {
            bookNowButton.setVisibility(View.GONE);
        }
    }

    private static JSONObject baseConfigJSON(){
        try {
            Log.e("resultPay: ", "base json");
            return new JSONObject()
                    .put("apiVersion", 2)
                    .put("apiVersionMinor", 0)
                    .put("allowedPaymentMethods", new JSONArray().put(getCardPaymentMethod()));
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static JSONObject getCardPaymentMethod() {
        final String[] networks = new String[]{"VISA"};
        final String[] authMeths = new String[]{"PAN_ONLY"};

        JSONObject card = new JSONObject();
        try {
            card.put("type", "CARD");
            card.put("tokenizationSpecification", getTokenSpec());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                card.put("parameters", new JSONObject()
                        .put("allowedAuthMethods", new JSONArray(authMeths))
                        .put("allowedCardNetworks", new JSONArray(networks))
                );
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return  card;
    }

    private static JSONObject getTokenSpec() throws JSONException {


        return new JSONObject() {{
            put("type", "PAYMENT_GATEWAY");
            put("parameters", new JSONObject() {{
                put("gateway", "example");
                put("gatewayMerchantId", "19216811");
            }});
        }};

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            // value passed in AutoResolveHelper
            case LOAD_PAYMENT_DATA_REQUEST_CODE:
                switch (resultCode) {

                    case Activity.RESULT_OK:
                        PaymentData paymentData = PaymentData.getFromIntent(data);
                        handlePaymentSuccess(paymentData);
                        break;

                    case Activity.RESULT_CANCELED:
                        // The user cancelled the payment attempt
                        break;

                    case AutoResolveHelper.RESULT_ERROR:
                        Status status = AutoResolveHelper.getStatusFromIntent(data);
//                        handleError(status.getStatusCode());
                        break;
                }

                // Re-enables the Google Pay payment button.
                bookNowButton.setClickable(true);
        }
    }

    private void handlePaymentSuccess(PaymentData paymentData) {

        // Token will be null if PaymentDataRequest was not constructed using fromJson(String).
        final String paymentInfo = paymentData.toJson();
        if (paymentInfo == null) {
            return;
        }

        try {
            JSONObject paymentMethodData = new JSONObject(paymentInfo).getJSONObject("paymentMethodData");
            // If the gateway is set to "example", no payment information is returned - instead, the
            // token will only consist of "examplePaymentMethodToken".

            final JSONObject tokenizationData = paymentMethodData.getJSONObject("tokenizationData");
            final String token = tokenizationData.getString("token");
            final JSONObject info = paymentMethodData.getJSONObject("info");
            final String billingName = info.getJSONObject("billingAddress").getString("name");
            Toast.makeText(
                    this, "Handle Payment Success" + billingName,
                    Toast.LENGTH_LONG).show();

            // Logging token string.
            Log.d("Google Pay token: ", token);

        } catch (JSONException e) {
            throw new RuntimeException("The selected garment cannot be parsed from the list of elements");
        }
    }
    //// End Google Payment


    // Google Route Map
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {

        map = googleMap;

        map.addMarker(pickUpLocation);
        map.addMarker(dropOffLocation);

    }

    private String getUrl(LatLng origin, LatLng dest, String directionMode) {
        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        // Mode
        String mode = "mode=" + directionMode;
        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        // Output format
        String output = "json";
        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + getString(R.string.google_maps_key);
        return url;
    }

    @Override
    public void onTaskDone(Object... values) {
        if(polyline != null)
        {
            polyline.remove();
        }
        polyline = map.addPolyline((PolylineOptions) values[0]);

    }
    // End Google Route Map

}


// Reference for Google Pay: https://developers.google.com/pay/api/android/guides/tutorial#checkoutactivity.java-java
// Reference for Google Route Map: https://www.youtube.com/watch?v=wRDLjUK8nyU