package com.example.task61;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.task61.data.UserDatabaseHelper;
import com.example.task61.model.User;

public class SignUpActivity extends AppCompatActivity {

    UserDatabaseHelper db;
    ImageButton addImageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        EditText suFullNameEditText = findViewById(R.id.suFullNameEditText);
        EditText phoneEditText = findViewById(R.id.phoneEditText);

        EditText suUserNameEditText = findViewById(R.id.suUserNameEditText);
        EditText suPasswordEditText = findViewById(R.id.suPasswordEditText);
        EditText suCPasswordEditText = findViewById(R.id.suCPasswordEditText);

        Button createAccountButton = findViewById(R.id.createAccountButton);
        addImageButton = findViewById(R.id.addImageButton);

        db = new UserDatabaseHelper(this);

        // Add Image
        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent imageUserIntent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
                final int ACTIVITY_SELECT_IMAGE = 1234;
                startActivityForResult(imageUserIntent, ACTIVITY_SELECT_IMAGE);
            }
        });

        // Create User Account and added to database for Login page
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username = suUserNameEditText.getText().toString();
                String password = suPasswordEditText.getText().toString();
                String confirmPassword = suCPasswordEditText.getText().toString();

                if(password.equals(confirmPassword))
                {
                    long result = db.insertUser(new User(username, password));
                    if(result > 0)
                    {
                        Toast.makeText(SignUpActivity.this, "Successfully Registered!",Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(SignUpActivity.this, "Registration error!",Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    Toast.makeText(SignUpActivity.this, "Please make sure both passwords are match!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Selected/got Image from photo gallery
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        switch(requestCode) {
            case 1234:
                if(resultCode == RESULT_OK){
                    Uri selectedImage = data.getData();
                    selectedImage.getPath();
                    String[] filePathColumn = {MediaStore.Images.Media.DATA};

                    Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                    cursor.moveToFirst();

//                    int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//                    String filePath = cursor.getString(columnIndex);
//                    cursor.close();

//                    Bitmap userimage = BitmapFactory.decodeFile(filePath);

                    addImageButton.setImageURI(selectedImage);
                }
        }

    };
}