package com.example.task61;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.PopupMenu;

import com.example.task61.data.TruckDatabaseHelper;
import com.example.task61.model.Truck;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    RecyclerView truckRecyclerView;
    TruckAdapter truckAdapter;
    List<Truck> truckList = new ArrayList<>();

    Integer[] truckImageList = {R.drawable.truck_icon, R.drawable.van_icon, R.drawable.refrigerated_truck_icon, R.drawable.mini_truck_icon};
    String[] truckNameList = {"Sam's Truck", "Lucy's Delivery", "CoCo's Fresh Service", "Mike's Mini-truck"};
    String[] truckVehicle = {"Truck", "Van", "Refrigerated Truck", "Mini-truck"};
    String[] truckGoods = {"Furniture Service", "Tourist Service", "Frozen Foods", "Individual House Moving"};
    String[] truckDate = {"Available Everyday", "Available Weekend", "Available Everyday", "Available Weekday"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageButton menuButton = findViewById(R.id.menuButton);
        ImageButton addButton = findViewById(R.id.addButton);
        truckRecyclerView = findViewById(R.id.truckRecyclerView);

        RecyclerView.LayoutManager truckLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        truckRecyclerView.setLayoutManager(truckLayoutManager);

        TruckDatabaseHelper truckDatabaseHelper = new TruckDatabaseHelper(this);
//
        for (int i = 0; i < truckNameList.length; i++)
        {
            Truck truck = new Truck(i, truckImageList[i], truckNameList[i], truckVehicle[i], truckGoods[i], truckDate[i]);
            truckList.add(truck);
        }

        truckAdapter = new TruckAdapter(truckList, HomeActivity.this);
        truckRecyclerView.setAdapter(truckAdapter);

        // Add Order to the MyOrder List
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addDeliveryIntent = new Intent(HomeActivity.this, NewDeliveryOrderOneActivity.class);
                startActivity(addDeliveryIntent);
            }
        });

        // Menu Pop Up to show other Activity
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(HomeActivity.this, menuButton);

                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {

                        switch (menuItem.getItemId()) {
                            case R.id.home:
                                Intent homeIntent = new Intent(HomeActivity.this, HomeActivity.class);
                                startActivity(homeIntent);
                                return true;
                            case R.id.account:
                                Intent accountIntent = new Intent(HomeActivity.this, SignUpActivity.class);
                                startActivity(accountIntent);
                                return true;
                            case R.id.myOrders:
                                Intent orderIntent = new Intent(HomeActivity.this, MyOrderActivity.class);
                                startActivity(orderIntent);
                                return true;
                            case R.id.logout:
                                Intent logoutIntent = new Intent(HomeActivity.this, MainActivity.class);
                                startActivity(logoutIntent);
                                return true;
                            default:
                                return false;
                        }



                    }
                });

                popupMenu.show();
            }
        });


    }


}